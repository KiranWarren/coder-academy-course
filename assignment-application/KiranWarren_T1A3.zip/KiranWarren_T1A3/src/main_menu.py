# Import modules.
from clear_terminal import *


def main_menu():
    '''
    This function displays all available functions for this application.
    '''
    clear_terminal()
    print("####################################")
    print(" TEXT FILE MANIPULATION APPLICATION ")
    print("####################################")
    print("Kiran Warren 2023\n")
    print('Functions:')
    print('[1] Replace Word in Text File')
    print('[2] Double Space Text File')
    print('[3] Encrypt Text File')
    print('[4] Decrypt Text File')
    print('[5] Word/Character Count of Text File')
    print('[6] Top Occurring Words in Text File')
    print('[7] Occurrence of Word in Text File')
    print('[Enter anything else to exit application]\n')
